# simple_lienar_regression

Description.
The package simple_lienar_regression is used to:

    Model Analysis :
    	- Plot fit model

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install simple_lienar_regression

```bash
pip install simple_lienar_regression
```

## Usage

```python
from package_name.module1_name import file1_name
file1_name.my_function()
```

## Author

Jefferson A Silva

## License

[MIT](https://choosealicense.com/licenses/mit/)
